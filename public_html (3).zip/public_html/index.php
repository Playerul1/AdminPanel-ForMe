<?php
// pornește SSA Admin Panel din /ssa-admin
require __DIR__ . '/ssa-admin/index.php';
